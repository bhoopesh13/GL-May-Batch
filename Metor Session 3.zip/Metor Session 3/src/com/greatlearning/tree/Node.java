package com.greatlearning.tree;

//A Binary Tree node
public class Node {
	int data;
	Node left, right;
	Node(int value) {
		data = value;
		left = right = null;
	}
}
