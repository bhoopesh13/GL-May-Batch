package com.greatlearning.stack.service;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Queue;
public class StackUsingQueue {
	Queue<Integer> queue ;
	Queue<Integer> tempQueue ;
	public StackUsingQueue()
	{
		queue = new LinkedList<Integer>();
		tempQueue = new LinkedList<Integer>();
	}
	public void push(int data)
	{
		/* if no element is present in queue then
enqueue the new element into queue */
		if (queue.size() == 0)
			queue.add(data);
		else
		{
			/* if elements are present in queue then
			 * dequeue all the elements to
			 * temporary Queue tempQueue */
			int size = queue.size();
			for (int i = 0; i < size; i++)
				tempQueue.add(queue.remove());
			/* enqueue the new element into queue */
			queue.add(data);
			/* dequeue all the elements from
			 * temporary Queue tempQueue to queue */
			for (int i = 0; i < size; i++)
				queue.add(tempQueue.remove());
		}
	}
	public int pop()
	{
		if (queue.size() == 0)
			throw new NoSuchElementException("Underflow Exception");
		return queue.remove();
	}
	public boolean isEmpty()
	{
		return queue.size() == 0 ;
	}
	public int getSize()
	{
		return queue.size();
	}
	public void display()
	{
		System.out.print("\nStack = ");
		int size = getSize();
		if (size == 0)
			System.out.print("Empty\n");
		else
		{
			Iterator<Integer> itr = queue.iterator();
			while (itr.hasNext())
				System.out.print(itr.next()+" ");
			System.out.println();
		}
	}
}