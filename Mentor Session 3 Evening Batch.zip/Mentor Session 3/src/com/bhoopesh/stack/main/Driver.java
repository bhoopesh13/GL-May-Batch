package com.bhoopesh.stack.main;

import java.util.NoSuchElementException;
import java.util.Scanner;

import com.bhoopesh.stack.service.StackUsingQueue;

public class Driver {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		StackUsingQueue stackUsingqueue = new StackUsingQueue();
		
		System.out.println("Stack using two queues \n");
		
		char ch;
		do {
			System.out.println("Stack operation");
			System.out.println("1. Push");
			System.out.println("2. Pop");
			System.out.println("3. check empty");
			System.out.println("4. size");
			
			
			int choice = sc.nextInt();
			
			switch(choice) {
			
			case 1:
				System.out.println("Enter the element to push");
				stackUsingqueue.push(sc.nextInt());
				break;
			case 2:
				try {
					System.out.println("Popped element = " + stackUsingqueue.pop());
				}
				catch(NoSuchElementException ex) {
					System.out.println("Error :" + ex.getMessage());
				}
				break;
			case 3:
				System.out.println("Empty status = " + stackUsingqueue.isEmpty());
				break;
			case 4:
				System.out.println("Size = " + stackUsingqueue.getSize());
				break;
			default:
				System.out.println("Enter the valid option \n");
				break;
			}
			stackUsingqueue.display();
			System.out.println("Do you want to continue or not (Type Y or N) \n");
			ch = sc.next().charAt(0);
		}
		while(ch == 'Y' || ch == 'y');
		sc.close();
	}

}
