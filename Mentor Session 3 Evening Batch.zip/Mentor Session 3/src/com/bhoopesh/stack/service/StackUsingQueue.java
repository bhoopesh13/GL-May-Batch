package com.bhoopesh.stack.service;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Queue;


// queue using two stacks
public class StackUsingQueue {

	Queue<Integer> queue;
	Queue<Integer> tempQueue;

	public StackUsingQueue() {
		queue = new LinkedList<Integer>();
		tempQueue = new LinkedList<Integer>();
	}
	
	public void push(int data) {

		if(queue.size() == 0)
			queue.add(data);
		else
		{
			int size = queue.size();
			for(int i = 0 ; i < size; i++) // queue.size
				tempQueue.add(queue.remove());
			
			queue.add(data);
			
			for(int i = 0 ; i < size; i++)
				queue.add(tempQueue.remove()); // tempQueue.size()
		}
	}

	public int pop() {
		if(queue.size() == 0)
			throw new NoSuchElementException("Underflow exception");
		return queue.remove();
	}

	public boolean isEmpty() {
		return queue.size() == 0;
	}

	public int getSize() {
		return queue.size();
	}

	public void display() {
		
		System.out.println("\n Stack =");
		if(queue.size() == 0)
			System.out.println("Stack is Empty\n");
		else
		{			
			Iterator<Integer> itr = queue.iterator();
			
			while(itr.hasNext()) {
				System.out.print(itr.next() + " ");
			}
			System.out.println();
		}
	}

}
