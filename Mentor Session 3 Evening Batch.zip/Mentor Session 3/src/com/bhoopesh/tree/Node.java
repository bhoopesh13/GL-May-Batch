package com.bhoopesh.tree;

public class Node {

	int data;
	Node left, right;
	
	Node(int value){
		data = value;
		left = right = null;
	}
}
