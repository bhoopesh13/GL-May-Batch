package com.bhoopesh.service;

public class ArrayRotation {

	public void leftRotate(int[] array, int element, int size) {
		
		
		for(int i = 0 ; i <= element; i++)
			leftRotateByone(array, size);
	}

	private void leftRotateByone(int[] array, int size) {
		
		int i, temp;
		temp = array[0];
		for(i = 0 ; i < size-1; i++)
			array[i] = array[i+1];
		array[size -1] = temp;
	}

}
