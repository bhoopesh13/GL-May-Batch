package com.bhoopesh.service;

import java.util.Scanner;

public class Banking {
	
	int bankBalance = 1000;
	Scanner sc = new Scanner(System.in);
	OTPGenerator otpG = new OTPGenerator();
	
	public void deposit()
	{
		int amount;
		System.out.println("Enter the amount you want to deposit");
		amount = sc.nextInt();
		
		if(amount > 0)
		{
			System.out.println("amount " + amount + " deposit successfully");
			bankBalance = bankBalance + amount;
			System.out.println("Remaining bank balance is : " + bankBalance);
		}
		else {
			System.out.println("Enter the correct amount");
		}
	}
	
	public void withdrawl()
	{
		int amount;
		System.out.println("Enter the amount you want to withdrawl");
		amount = sc.nextInt();
		
		if(amount > 0 && bankBalance-amount >= 0)
		{
			System.out.println("amount " + amount + " withdrawl successfully");
			bankBalance = bankBalance - amount;
			System.out.println("Remaining bank balance is : " + bankBalance);
		}
		else {
			System.out.println("Insufficient funds or incorrect amounts");
		}
		
	}

	public void transfer()
	{
		int amount;
		int otp;
		int otpGenerated;
		int bankAccountNo;
		
		System.out.println("Enter the otp");
		otpGenerated = otpG.generateOTP();
		System.out.println(otpGenerated);
		
		otp = sc.nextInt();
		
		if(otp == otpGenerated)
		{
			System.out.println("otp verification successfull");
			
			System.out.println("Enter the amount and bank account to which you want to transfer");
			
			amount = sc.nextInt();
			bankAccountNo = sc.nextInt();
			
			if(amount > 0 && bankBalance-amount >= 0)
			{
				System.out.println("amount " + amount + " transfer successfully to bank account " + bankAccountNo);
				bankBalance = bankBalance - amount;
				System.out.println("Remaining bank balance is : " + bankBalance);
			}
			else {
				System.out.println("Insufficient funds or incorrect amounts");
			}
		}
		else
		{
			System.out.println("Invalid otp, try again");
		}
		
	}
}
