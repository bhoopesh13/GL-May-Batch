package com.bhoopesh.service;

public class OTPGenerator {

	public int generateOTP()
	{
		
		
		//0.0 to .9999
		//1000 to 9999
		
		/*
		 * random password -> uppercase, lowercase, number, special chars -> Random
		 */
		int randomPin = 0;	
		randomPin = (int) (Math.random() * 9000) + 1000;	
		return randomPin;
	}
}
