package com.bhoopesh.main;

import java.util.Scanner;

import com.bhoopesh.model.Customer;
import com.bhoopesh.service.Banking;

public class Driver {
	
	public static void main(String[] args) {
		
		
		Banking banking = new Banking();
		Customer customer1 = new Customer("123456", "password"); // password
		
		Scanner sc = new Scanner(System.in);
		
		String bankAccountNo;
		String password;
		
		// /n -> new line
		System.out.println("Welcome to login page");
		System.out.println();
		
		System.out.println("Enter the bank account no");
		bankAccountNo = sc.nextLine();
		
		System.out.println("Enter the password for bank account");
		password = sc.nextLine();
		
		
		if(customer1.getBankAccountNo().equals(bankAccountNo)  &&
				customer1.getPassword().equals(password))
		{
			System.out.println("\nWelcome to Indian Bank\n");
			int option;
			
			do {
				System.out.println("-----------------------------------");
				System.out.println("Please enter the operation you want to perform");
				System.out.println("1. Deposit");
				System.out.println("2. Withdrawl");
				System.out.println("3. Transfer");
				System.out.println("0. Logout");
				System.out.println("-----------------------------------");

				option = sc.nextInt();
				
				
				switch(option)
				{
				case 0:
					break;
				case 1:
					banking.deposit();
					break;
				case 2:
					banking.withdrawl();
					break;
				case 3:
					banking.transfer();
					break;
				default:
					System.out.println("Enter valid option");
				}

				
			}while(option != 0); 
			System.out.println("Exited Successfully.");
		}
		else
		{
			System.out.println("Invalid Credentials");
		}
		
	}

}
